package com.example.demo_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
